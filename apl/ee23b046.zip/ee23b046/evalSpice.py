import numpy as np

def evalSpice(filename):
    if not filename:
        raise FileNotFoundError('Please give the name of a valid SPICE file as input')

    try:
        with open(filename, 'r') as file:
            lines = file.readlines()
    except FileNotFoundError:
        raise FileNotFoundError('Please give the name of a valid SPICE file as input')

    component = []
    tot_vol = 0
    nodes = {'GND': 0}  # Node 0 corresponds to GND
    tot_node = 1  

    its_circuit = False
    circuit_started = False

    # Parse the file and extract components and nodes
    with open(filename, 'r') as file:
        for line in file:
            line = line.strip()

            if line == ".circuit":
                if circuit_started:
                    raise ValueError("Malformed circuit file")
                its_circuit = True
                circuit_started = True
                continue
            elif line == ".end":
                its_circuit = False
                break

            if its_circuit:
                elements = line.split()

                if len(elements) < 4:
                    raise ValueError("Malformed circuit file")

                name, node1, node2 = elements[:3]
                comp = {'name': name, 'node1': node1, 'node2': node2}

                #assigns each component inside the dict
                if name.startswith('R'): 
                    comp['type'] = 'R'
                    comp['value'] = float(elements[3])
                elif name.startswith('V'):
                    comp['type'] = 'V'
                    if elements[3] == 'dc':
                        comp['value'] = float(elements[4])
                    else:
                        comp['value'] = float(elements[3])
                elif name.startswith('I'):
                    comp['type'] = 'I'
                    if elements[3] == 'dc':
                        comp['value'] = float(elements[4])
                    else:
                        comp['value'] = float(elements[3])
                else:
                    raise ValueError("Only V, I, R elements are permitted")

                component.append(comp)

                # Map the nodes if they are not 'GND'
                if node1 != 'GND':
                    if node1 not in nodes:
                        nodes[node1] = tot_node
                        tot_node += 1
                if node2 != 'GND':
                    if node2 not in nodes:
                        nodes[node2] = tot_node
                        tot_node += 1
                if name.startswith('V'):
                    tot_vol += 1

    if not circuit_started:
        raise ValueError("Malformed circuit file")

    # Matrix dimensions: (number of nodes - 1) + number of independent voltage sources
    index = tot_node - 1 + tot_vol  # Nodes (excluding GND) + voltage sources

    # Initialize G matrix (conductance matrix) and I matrix (current/voltage sources)
    G = np.zeros((index, index))
    I = np.zeros(index)

    # Build matrix from components
    voltage_sources = []
    voltage_index = tot_node - 1  # Track voltage sources separately

    for comp in component:
        node1 = nodes[comp['node1']]
        node2 = nodes[comp['node2']]

        if comp['node1'] == 'GND':
            node1 = 0
        if comp['node2'] == 'GND':
            node2 = 0

        if comp['type'] == 'R':  # Resistor
            value = 1 / comp['value']  # Conductance (G = 1/R)
            if node1 != 0:  # If node1 is not ground, update diagonal
                G[node1 - 1][node1 - 1] += value
            if node2 != 0:  # If node2 is not ground, update diagonal
                G[node2 - 1][node2 - 1] += value
            if node1 != 0 and node2 != 0:  # Update off-diagonal terms
                G[node1 - 1][node2 - 1] -= value
                G[node2 - 1][node1 - 1] -= value

        elif comp['type'] == 'V':  # Voltage source
            voltage_sources.append(comp['name'])
            if node1 != 0:  # Add voltage source constraints in G matrix
                G[voltage_index][node1 - 1] = 1
                G[node1 - 1][voltage_index] = 1
            if node2 != 0:
                G[voltage_index][node2 - 1] = -1
                G[node2 - 1][voltage_index] = -1
            I[voltage_index] = comp['value']  # Add voltage source value in I vector
            voltage_index += 1

        elif comp['type'] == 'I':  # Current source
            if node1 != 0:
                I[node1 - 1] -= comp['value']
            if node2 != 0:
                I[node2 - 1] += comp['value']

    # Check for matrix rank deficiency
    if np.linalg.matrix_rank(G) < index:
        raise ValueError("Circuit error: no solution")

    # Solve the matrix equation G * V = I for node voltages V
    try:
        V = np.linalg.solve(G, I)
    except np.linalg.LinAlgError:
        raise ValueError("Circuit error: no solution")

    # Map voltages back to node names and report current through voltage sources
    voltage_dict = {name: V[nodes[name] - 1] for name in nodes if name != 'GND'}
    voltage_dict['GND'] = 0
    current_dict = {voltage_sources[i]: V[tot_node - 1 + i] for i in range(tot_vol)}

    return voltage_dict, current_dict

